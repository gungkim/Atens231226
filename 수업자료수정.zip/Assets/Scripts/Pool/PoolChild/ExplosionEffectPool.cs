using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Pool;

public class ExplosionEffectPool : ObjectPool<Explosion>
{
}